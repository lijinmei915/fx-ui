# fx-ui 前端样式包 — 优化须知（先读这页）

这是 fx-ui 文档站/组件库的前端样式源码，交给你做**视觉/样式优化**。下面是技术栈和**必须遵守的约束**——不按这些改会被打回。

## 技术栈
- **React + TypeScript + Tailwind CSS v4 + shadcn/ui（open-code）+ Base UI（`@base-ui/react`，不是 Radix）**
- 设计 token 真相源：`theme/fx-theme.css`（颜色/字号/间距/圆角/阴影/动效全在这）
- 整页：`src/App.tsx`（文档站，含顶栏/导航/各组件页/列表页模板）
- 组件：`src/components/ui`（基础）/`fx`（组合）/`recipes`（页面区块）

## 🚫 优化时的硬约束（重要）
1. **颜色/尺寸只能用语义 token，禁止写死值。** 用 `bg-primary` / `text-foreground` / `text-fx-13` / `border-border` 这类类名；**不要**出现 hex（`#fff`）、`rgb()`、`color-mix()`、任意 `px` 色值。要新色就改 `theme/fx-theme.css` 的变量，不在组件里写死。
   - 字号档：`text-fx-12 / fx-13 / fx-15 / fx-18`（无 14）。
2. **不重写组件结构，只调 Tailwind class 或 token。** shadcn 是 open-code，可改 class，但别把组件推倒重写、别改它的 `data-slot` 语义。
3. **不在调用处用 className 覆盖组件外观**（颜色/圆角/边框/底色）。要某组件长得不一样 → 给它加一个 `variant`，不要在用的地方 className 硬盖。
4. **图标**统一从 `@/lib/icons`（Tabler）来，别引第二个图标库、别裸写 `<svg>`。
5. **交互态**（hover/active/disabled）走 token（`*-hover/active/disabled`），别用 `opacity-50` 伪装、别用透明度。
6. 半透明填充用 `bg-fill-subtle` / `bg-fill-hover`（已是自适应宿主底色的 token）。

## 你可以放手做的
- 调间距/留白/对齐/层级、圆角档、阴影档（都有 token，挑合适的档）
- 优化各组件视觉细节、状态反馈、排版节奏
- 提出"某处该新增一个 token / variant"的建议（写清理由）

## 怎么交付优化结果
- 直接改源码文件，或给出**按文件的 diff / 改动说明**。
- 若新增/改了 token，请同时说明改的是 `theme/fx-theme.css` 的哪个变量。
- 一句话总结你改了什么、为什么、是否新增 token/variant。

> 一句话：**视觉走 token，结构别乱动，外观差异用 variant 不用覆盖。** 这是这套体系的命脉。
